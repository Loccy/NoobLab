There are two examples in this directory.

If you are new to `abandon` then have a look at the `simple` example first.

The `complete` example showcases many features of abandon, and can be used as a reference
for managing your acutal accounts.
